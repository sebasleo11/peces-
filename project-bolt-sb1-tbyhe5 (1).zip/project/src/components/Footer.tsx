import { Youtube, Instagram, MessageSquare, Phone } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">InteliGENTE11</h3>
            <p className="text-gray-400">
              Gracias por ser parte de nuestra comunidad tecnológica
            </p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">Enlaces Rápidos</h3>
            <div className="flex space-x-4">
              <a
                href="https://www.youtube.com/@InteliGENTE11"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Youtube size={24} />
              </a>
              <a
                href="https://instagram.com/InteliGENTE1979"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Instagram size={24} />
              </a>
              <a
                href="https://wa.me/5491140930260"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <Phone size={24} />
              </a>
              <a
                href="https://chatgpt.com/g/g-OzsHxROYm-inteligente"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-white transition-colors"
              >
                <MessageSquare size={24} />
              </a>
            </div>
          </div>
          <div>
            <p className="text-gray-400">
              © 2024 InteliGENTE11. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}