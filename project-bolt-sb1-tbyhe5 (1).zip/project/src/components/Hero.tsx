import { Youtube } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="pt-24 pb-16 bg-gradient-to-b from-blue-50 to-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent">
            Bienvenido a InteliGENTE11
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-8">
            Descubre el futuro de la tecnología, herramientas digitales y estrategias de éxito
          </p>
          <p className="text-lg text-gray-600 mb-8">
            InteliGENTE11 es un proyecto donde exploramos las posibilidades de la inteligencia artificial, 
            compartimos estrategias de marketing digital y enseñamos a aprovechar las herramientas tecnológicas del futuro.
          </p>
          <a
            href="https://www.youtube.com/@InteliGENTE11"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center px-8 py-4 bg-red-600 text-white rounded-full hover:bg-red-700 transition-colors"
          >
            <Youtube className="mr-2" />
            Suscríbete a nuestro canal
          </a>
        </div>
      </div>
    </section>
  );
}