interface Video {
  id: string;
  title: string;
  thumbnail: string;
}

const featuredVideos: Video[] = [
  {
    id: '1',
    title: 'Introducción a la IA',
    thumbnail: 'https://images.unsplash.com/photo-1677442136019-21780ecad995',
  },
  {
    id: '2',
    title: 'Marketing Digital 2024',
    thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f',
  },
  {
    id: '3',
    title: 'Herramientas del Futuro',
    thumbnail: 'https://images.unsplash.com/photo-1535378917042-10a22c95931a',
  },
];

export default function Content() {
  return (
    <section id="content" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Contenido Destacado</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {featuredVideos.map((video) => (
            <div key={video.id} className="group">
              <div className="relative overflow-hidden rounded-lg shadow-lg">
                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="w-full h-48 object-cover transform group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="absolute bottom-4 left-4 text-white">
                    <h3 className="font-semibold">{video.title}</h3>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="text-center mt-12">
          <a
            href="https://www.youtube.com/@InteliGENTE11"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-8 py-3 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors"
          >
            Ver más videos
          </a>
        </div>
      </div>
    </section>
  );
}