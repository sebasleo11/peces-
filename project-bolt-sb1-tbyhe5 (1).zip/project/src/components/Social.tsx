import { Instagram, MessageSquare, Youtube, Phone } from 'lucide-react';

const socialLinks = [
  {
    name: 'YouTube',
    icon: Youtube,
    href: 'https://www.youtube.com/@InteliGENTE11',
    color: 'bg-red-600 hover:bg-red-700',
  },
  {
    name: 'Instagram',
    icon: Instagram,
    href: 'https://instagram.com/InteliGENTE1979',
    color: 'bg-pink-600 hover:bg-pink-700',
  },
  {
    name: 'WhatsApp',
    icon: Phone,
    href: 'https://wa.me/5491140930260',
    color: 'bg-green-500 hover:bg-green-600',
  },
  {
    name: 'ChatGPT-inteliGENTE',
    icon: MessageSquare,
    href: 'https://chatgpt.com/g/g-OzsHxROYm-inteligente',
    color: 'bg-blue-600 hover:bg-blue-700',
  },
];

export default function Social() {
  return (
    <section id="social" className="py-16 bg-blue-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-8">Redes Sociales</h2>
        <p className="text-center text-gray-600 mb-12">
          Síguenos en nuestras redes sociales para más contenido exclusivo
        </p>
        <div className="flex flex-wrap justify-center gap-6">
          {socialLinks.map((social) => (
            <a
              key={social.name}
              href={social.href}
              target="_blank"
              rel="noopener noreferrer"
              className={`flex items-center px-6 py-3 ${social.color} text-white rounded-full transition-colors`}
            >
              <social.icon className="mr-2" size={20} />
              {social.name}
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}