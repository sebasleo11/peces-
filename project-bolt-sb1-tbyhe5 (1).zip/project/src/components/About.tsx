export default function About() {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8">Sobre Nosotros</h2>
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="flex-1">
              <img
                src="https://images.unsplash.com/photo-1531297484001-80022131f5a1"
                alt="Technology"
                className="rounded-lg shadow-lg"
              />
            </div>
            <div className="flex-1">
              <p className="text-gray-600 leading-relaxed">
                En InteliGENTE11 estamos comprometidos con el aprendizaje continuo, 
                el uso de herramientas digitales y la difusión de conocimiento sobre 
                inteligencia artificial y marketing digital.
              </p>
              <p className="text-gray-600 leading-relaxed mt-4">
                Nuestra misión es hacer que la tecnología sea accesible para todos, 
                proporcionando contenido de calidad y manteniéndote actualizado con 
                las últimas tendencias en el mundo digital.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}