import Header from './components/Header';
import Hero from './components/Hero';
import Content from './components/Content';
import Social from './components/Social';
import About from './components/About';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <Content />
        <Social />
        <About />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;